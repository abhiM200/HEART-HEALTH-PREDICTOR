import numpy as np
import pandas as pd
import streamlit as st
import time
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier, AdaBoostClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, confusion_matrix
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV, cross_val_score, learning_curve
from sklearn.tree import DecisionTreeClassifier
import matplotlib.pyplot as plt
import seaborn as sns

def train_models(X_train, y_train):
    """
    Train multiple machine learning models on the training data.
    
    Args:
        X_train: Training features
        y_train: Training target
        
    Returns:
        models: Dictionary of trained models
    """
    models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
        'Gradient Boosting': GradientBoostingClassifier(random_state=42),
        'SVM': SVC(probability=True, random_state=42),
        'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=5)
    }
    
    # Train each model
    for name, model in models.items():
        model.fit(X_train, y_train)
    
    # Add an ensemble model (voting classifier)
    estimators = [(name, model) for name, model in models.items()]
    ensemble = VotingClassifier(estimators=estimators, voting='soft')
    ensemble.fit(X_train, y_train)
    models['Voting Ensemble'] = ensemble
    
    # Add AdaBoost model
    ada = AdaBoostClassifier(random_state=42)
    ada.fit(X_train, y_train)
    models['AdaBoost'] = ada
    
    # Add a Neural Network (MLP) model
    mlp = MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=1000, random_state=42)
    mlp.fit(X_train, y_train)
    models['Neural Network'] = mlp
    
    return models

def evaluate_models(models, X_test, y_test):
    """
    Evaluate trained models on test data.
    
    Args:
        models: Dictionary of trained models
        X_test: Test features
        y_test: Test target
        
    Returns:
        results: Dictionary of evaluation metrics for each model
    """
    results = {}
    
    for name, model in models.items():
        # Make predictions
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        # Calculate ROC curve and AUC
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        auc_score = auc(fpr, tpr)
        
        # Store results
        results[name] = {
            'Accuracy': accuracy,
            'Precision': precision,
            'Recall': recall,
            'F1 Score': f1,
            'AUC': auc_score,
            'FPR': fpr,
            'TPR': tpr
        }
    
    return results

def predict(model, input_data):
    """
    Make predictions using a trained model.
    
    Args:
        model: Trained machine learning model
        input_data: DataFrame with features for prediction
        
    Returns:
        predictions: Predicted class (0 or 1)
        probabilities: Probability of positive class
    """
    # Make prediction
    prediction = model.predict(input_data)
    
    # Get probability
    probability = model.predict_proba(input_data)[:, 1]
    
    return prediction, probability
    
def hyperparameter_tuning(X_train, y_train, model_name='random_forest', cv=3, n_iter=10):
    """
    Perform hyperparameter tuning for the selected model.
    
    Args:
        X_train: Training features
        y_train: Training target
        model_name: Name of the model to tune ('random_forest', 'logistic_regression', 'svm', 'gradient_boosting', 'xgboost')
        cv: Number of cross-validation folds
        n_iter: Number of iterations for randomized search
        
    Returns:
        best_model: The best model after hyperparameter tuning
        best_params: The best hyperparameters found
        scores: Cross-validation scores
    """
    if model_name == 'random_forest':
        # Random Forest hyperparameters
        model = RandomForestClassifier(random_state=42)
        param_grid = {
            'n_estimators': [50, 100, 200],
            'max_depth': [None, 10, 20, 30],
            'min_samples_split': [2, 5, 10],
            'min_samples_leaf': [1, 2, 4],
            'max_features': ['sqrt', 'log2', None]
        }
        
    elif model_name == 'logistic_regression':
        # Logistic Regression hyperparameters
        model = LogisticRegression(random_state=42, max_iter=1000)
        param_grid = {
            'C': [0.01, 0.1, 1.0, 10.0],
            'penalty': ['l1', 'l2', 'elasticnet', None],
            'solver': ['newton-cg', 'lbfgs', 'liblinear', 'sag', 'saga']
        }
        
    elif model_name == 'svm':
        # SVM hyperparameters
        model = SVC(probability=True, random_state=42)
        param_grid = {
            'C': [0.1, 1, 10, 100],
            'gamma': ['scale', 'auto', 0.1, 0.01],
            'kernel': ['rbf', 'poly', 'sigmoid']
        }
        
    elif model_name == 'gradient_boosting':
        # Gradient Boosting hyperparameters
        model = GradientBoostingClassifier(random_state=42)
        param_grid = {
            'n_estimators': [50, 100, 200],
            'learning_rate': [0.01, 0.1, 0.2],
            'max_depth': [3, 5, 7],
            'min_samples_split': [2, 5, 10],
            'subsample': [0.8, 0.9, 1.0]
        }
        
    elif model_name == 'adaboost':
        # AdaBoost hyperparameters
        model = AdaBoostClassifier(random_state=42)
        param_grid = {
            'n_estimators': [50, 100, 200],
            'learning_rate': [0.01, 0.1, 0.2],
            'algorithm': ['SAMME', 'SAMME.R']
        }
        
    else:
        st.error(f"Model '{model_name}' not supported for hyperparameter tuning.")
        return None, None, None
    
    # Progress bar
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    # Use RandomizedSearchCV for faster tuning
    search = RandomizedSearchCV(estimator=model, param_distributions=param_grid, 
                                n_iter=n_iter, cv=cv, scoring='accuracy', 
                                random_state=42, n_jobs=-1)
    
    # Fit the model with progress tracking
    total_iterations = n_iter * cv
    iteration = 0
    
    # Start timer
    start_time = time.time()
    
    # Fit the model
    try:
        search.fit(X_train, y_train)
        
        # Get results
        best_model = search.best_estimator_
        best_params = search.best_params_
        cv_results = search.cv_results_
        
        # Get mean cross-validation scores
        mean_scores = cv_results['mean_test_score']
        
        # Update progress to 100%
        progress_bar.progress(1.0)
        elapsed_time = time.time() - start_time
        status_text.text(f"Hyperparameter tuning completed in {elapsed_time:.2f} seconds.")
        
        return best_model, best_params, mean_scores
        
    except Exception as e:
        st.error(f"Error during hyperparameter tuning: {e}")
        return None, None, None
